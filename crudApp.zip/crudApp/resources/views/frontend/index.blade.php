@extends('layouts.master')
@section('content')
    <div class="container col-lg-8">
        <h1>Member</h1>
        <a class="btn-info float-right" href="{{route('create')}}" style="display:inline-block">aa</a>
        <table class="table table-bordered">
            <thead class="thead-dark">
            <tr>
                <th scope="col">S.No</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone No.</th>
                <th scope="col">Image</th>
                <th scope="col">Status</th>
                <th scope="col" style="display:inline-block">Action</th>
            </tr>
            </thead>
            <tbody>
            @foreach($datas as $data)
                <tr>
                    <td>{{$loop->iteration}}</td>
                    <td>{{$data->name}}</td>
                    <td>{{$data->email}}</td>
                    <td>{{$data->phone_no}}</td>
                    <td><img src="{{asset("$data->image")}}" style="display:inline-block"></td>
                    <td>
                        @if($data->status==1)
                            Active
                            @else
                            Offline
                            @endif
                    </td>
                    <td>
                    <a href="" class="btn btn-primary" style="display:inline-block">Edit</a>
                    <a onclick="alert('DO you want to delete')"href="" class="btn btn-danger" style="display:inline-block">Delete</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {{$datas->links()}}
    </div>
    @endsection