<head>
<head>
    <title>Laravel Project</title>
    <link rel="stylesheet" href="{{asset('Frontend/css/bootstrap.css')}}">
<body>

@yield('content')
</body>
</head>
