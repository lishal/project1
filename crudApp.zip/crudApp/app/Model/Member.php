<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    protected $primaryKey='member_id';
    protected $fillable =[
        'name','email','phone_no','image','password','status',
    ];
}
