<?php

namespace App\Http\Controllers;

use App\Model\Member;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    public function create(){
        return view('frontend.create');
    }
    public function edit(){
        return view('frontend.edit');
    }
    public function index(){
        $datas=Member::orderBy('member_id','desc')->paginate(2);
        return view('frontend.index',compact('datas'));
    }
    public function master(){
        return view('layouts.master');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
//        $request->validate([
//            'name'=> 'required|min:3|max:50',
//            'email'=>'email',
//            'phone'=>'required|min:10|numeric',
//            'password'=>'required|confirmed|min:6',
//            'image'=>'mimes:jpeg,jpg,pnp,gig',
//        ]);
        $member= new Member();
        $member->name=$request->email;
        $member->email=$request->phone;
        $member->phone_no=($request->password);
        $member->status=$request->status;
        if($request->hasFile('image')){
            $image=$request->image;
            $fileName=time()."." . $image->getClientOriginalExtension();
            $destination_path=public_path("member/");
            $image->move($destination_path,$fileName);
            $member->image='member/' . $fileName;
        }
        $membersave=$member->save();
        if($membersave){
            return redirect()->back()->with("success","The record has been stored");
        }
        else{
            return redirect()->back()->with("error","Error storing data");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
