<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/create','MemberController@create')->name('create');
Route::get('/edit','MemberController@edit')->name('edit');
Route::get('/index','MemberController@index')->name('index');
Route::get('/','MemberController@master')->name('master');
Route::post('/store','MemberController@store')->name('store');
