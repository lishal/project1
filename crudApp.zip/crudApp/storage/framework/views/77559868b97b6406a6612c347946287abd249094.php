<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-2 jumbotron">
                <?php if(\Illuminate\Support\Facades\Session::has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo session('error'); ?>

                    </div>
                <?php endif; ?>
                    <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo session('success'); ?>

                        </div>
                    <?php endif; ?>
        <form action="<?php echo e(route('store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" id="name" class="form-control">
                    </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" name="email" id="email" class="form-control">
                <span style="color: red"><?php echo e($errors->first('email')); ?></span>
            </div>
            <div class="form-group">
                <label for="email">Phone Number</label>
                <input type="number" name="phone" id="phone" class="form-control">
                <span style="color: red"><?php echo e($errors->first('phone')); ?></span>
            </div>
            <div class="form-group">
                <label for="image">Picture</label>
                <input type="file" name="image" id="imgID" class="btn btn-default">

            </div>
            <div class="form-group">
                <label for="email">Password</label>
                <input type="password" name="password" id="password" class="form-control">
            </div>
            <div class="form-group">
                <label for="email">Password Confirmation</label>
                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <br>
                <input type="radio" class="" name="status" id="user status" value="1">Active
                <input type="radio" class="" name="status" id="user status" value="0">Offline
            </div>
            <div class="form-group float-right">
                <button class="btn btn-primary float-left">Submit</button>
            </div>
            </form></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\crudApp\resources\views/frontend/create.blade.php ENDPATH**/ ?>