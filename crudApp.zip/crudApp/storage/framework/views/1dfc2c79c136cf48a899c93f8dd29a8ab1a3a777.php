<head>
<head>
    <title>Laravel Project</title>
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/css/bootstrap.css')); ?>">
<body>

<?php echo $__env->yieldContent('content'); ?>
</body>
</head>
<?php /**PATH D:\LARAVEL\crudApp\resources\views/layouts/master.blade.php ENDPATH**/ ?>