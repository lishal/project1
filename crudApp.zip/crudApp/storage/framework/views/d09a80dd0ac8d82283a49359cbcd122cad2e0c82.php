<?php $__env->startSection('content'); ?>
    <div class="container col-lg-8">
        <h1>Member</h1>
        <a class="btn-info float-right" href="<?php echo e(route('create')); ?>" style="display:inline-block">aa</a>
        <table class="table table-bordered">
            <thead class="thead-dark">
            <tr>
                <th scope="col">S.No</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone No.</th>
                <th scope="col">Image</th>
                <th scope="col">Status</th>
                <th scope="col" style="display:inline-block">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->phone_no); ?></td>
                    <td><img src="<?php echo e(asset("$data->image")); ?>" style="display:inline-block"></td>
                    <td>
                        <?php if($data->status==1): ?>
                            Active
                            <?php else: ?>
                            Offline
                            <?php endif; ?>
                    </td>
                    <td>
                    <a href="" class="btn btn-primary" style="display:inline-block">Edit</a>
                    <a onclick="alert('DO you want to delete')"href="" class="btn btn-danger" style="display:inline-block">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($datas->links()); ?>

    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\crudApp\resources\views/frontend/index.blade.php ENDPATH**/ ?>